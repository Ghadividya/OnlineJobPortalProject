package in.co.job.portal.bean;

import java.util.Date;

public class MakeResumeBean extends BaseBean {

	private String name;
	private String email;
	private String mobile;
	private String gCourceName;
	private String gInsName;
	private String gPercentage;
	private String hCourceName;
	private String hInsName;
	private String hPercentage;
	private String sCourceName;
	private String sInsName;
	private String sPercentage;
	private String skill;
	private String hobbies;
	private String pDetail;
	private String declaration;
	private Date date;
	private String place;
	private String objective;
	
	
	
	
	
	
	
	public String getObjective() {
		return objective;
	}

	public void setObjective(String objective) {
		this.objective = objective;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getgCourceName() {
		return gCourceName;
	}

	public void setgCourceName(String gCourceName) {
		this.gCourceName = gCourceName;
	}

	public String getgInsName() {
		return gInsName;
	}

	public void setgInsName(String gInsName) {
		this.gInsName = gInsName;
	}

	public String getgPercentage() {
		return gPercentage;
	}

	public void setgPercentage(String gPercentage) {
		this.gPercentage = gPercentage;
	}

	public String gethCourceName() {
		return hCourceName;
	}

	public void sethCourceName(String hCourceName) {
		this.hCourceName = hCourceName;
	}

	public String gethInsName() {
		return hInsName;
	}

	public void sethInsName(String hInsName) {
		this.hInsName = hInsName;
	}

	public String gethPercentage() {
		return hPercentage;
	}

	public void sethPercentage(String hPercentage) {
		this.hPercentage = hPercentage;
	}

	public String getsCourceName() {
		return sCourceName;
	}

	public void setsCourceName(String sCourceName) {
		this.sCourceName = sCourceName;
	}

	public String getsInsName() {
		return sInsName;
	}

	public void setsInsName(String sInsName) {
		this.sInsName = sInsName;
	}

	public String getsPercentage() {
		return sPercentage;
	}

	public void setsPercentage(String sPercentage) {
		this.sPercentage = sPercentage;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getHobbies() {
		return hobbies;
	}

	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}

	public String getpDetail() {
		return pDetail;
	}

	public void setpDetail(String pDetail) {
		this.pDetail = pDetail;
	}

	public String getDeclaration() {
		return declaration;
	}

	public void setDeclaration(String declaration) {
		this.declaration = declaration;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
